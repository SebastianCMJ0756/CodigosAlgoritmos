
class Nodito:
    def __init__(self, nombre, demanda=0, ventana_tiempo=None):
        self.nombre = nombre
        self.vecinos = []
        self.demanda = demanda  
        self.ventana_tiempo = ventana_tiempo or (0, 24)  
